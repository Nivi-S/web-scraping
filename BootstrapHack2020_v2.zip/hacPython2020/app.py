from flask import Flask, render_template, request
app = Flask(__name__)


# @app.route('/googlenews/', method=['GET'])
# def googlenews():
#     newsapi = NewsApiClient(api_key"")
#     topheadlines = newsapi.get_top_headlines(sources="cnn, fox-news")
#     return jsonify(topheadlines)

# @app.route("/")
# def hello():
#     return "Hello wwwwWorld!"

@app.route("/")
def hello():
    return render_template("index.html")

# @app.route('/about')
# def aboutpage():
#
#     title = "About this site"
#     paragraph = ["blah blah blah memememememmeme blah blah memememe"]
#
#     pageType = 'about'
#
#     return render_template("index.html", title=title, paragraph=paragraph, pageType=pageType)
#
# @app.route('/about/contact')
# def contactPage():
#
#     title = "About this site"
#     paragraph = ["blah blah blah memememememmeme blah blah memememe"]
#
#     pageType = 'about'
#
#     return render_template("index.html", title=title, paragraph=paragraph, pageType=pageType)

if __name__ == "__main__":
	app.run(debug = True, host='0.0.0.0', port=8080, passthrough_errors=True)